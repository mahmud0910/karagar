<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_login();

header('Content-Type: application/json');

$productId = (int)($_GET['product_id'] ?? 0);
$stmt = $pdo->prepare("SELECT id, size, color, stock_qty FROM product_variants WHERE product_id = ? ORDER BY size, color");
$stmt->execute([$productId]);
echo json_encode($stmt->fetchAll());
