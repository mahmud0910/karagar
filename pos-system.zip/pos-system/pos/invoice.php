<?php
$page_title = 'Invoice';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("
    SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.address as customer_address, u.name as staff_name
    FROM sales s JOIN customers c ON c.id = s.customer_id JOIN users u ON u.id = s.user_id
    WHERE s.id = ?
");
$stmt->execute([$id]);
$sale = $stmt->fetch();
if (!$sale) { die('Invoice পাওয়া যায়নি।'); }

$itemStmt = $pdo->prepare("SELECT * FROM sale_items WHERE sale_id = ?");
$itemStmt->execute([$id]);
$items = $itemStmt->fetchAll();
?>

<div class="d-flex justify-content-between mb-3 no-print">
  <a href="/pos/index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> নতুন Sale</a>
  <button onclick="window.print()" class="btn btn-dark"><i class="bi bi-printer"></i> Print Invoice</button>
</div>

<div class="card p-4 mx-auto" style="max-width:600px;">
  <div class="text-center mb-3">
    <h4><?= SITE_NAME ?></h4>
    <small class="text-muted">Invoice / Receipt</small>
  </div>
  <hr>
  <div class="d-flex justify-content-between">
    <div>
      <strong>Invoice No:</strong> <?= h($sale['invoice_no']) ?><br>
      <strong>Date:</strong> <?= date('d M Y, h:i A', strtotime($sale['created_at'])) ?><br>
      <strong>Staff:</strong> <?= h($sale['staff_name']) ?>
    </div>
    <div class="text-end">
      <strong>Customer:</strong> <?= h($sale['customer_name']) ?><br>
      <strong>Phone:</strong> <?= h($sale['customer_phone']) ?><br>
      <?php if ($sale['customer_address']): ?><strong>Address:</strong> <?= h($sale['customer_address']) ?><?php endif; ?>
    </div>
  </div>
  <hr>
  <table class="table table-sm">
    <thead><tr><th>Item</th><th>Size/Color</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
    <tbody>
      <?php foreach ($items as $it): ?>
      <tr>
        <td><?= h($it['product_name']) ?></td>
        <td><?= h($it['size']) ?>/<?= h($it['color']) ?></td>
        <td><?= $it['qty'] ?></td>
        <td><?= money($it['price']) ?></td>
        <td><?= money($it['line_total']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <hr>
  <div class="d-flex justify-content-between"><span>Subtotal</span><span><?= money($sale['subtotal']) ?></span></div>
  <div class="d-flex justify-content-between"><span>Discount</span><span><?= money($sale['discount']) ?></span></div>
  <div class="d-flex justify-content-between fs-5"><strong>Total</strong><strong><?= money($sale['total']) ?></strong></div>
  <div class="d-flex justify-content-between"><span>Paid</span><span><?= money($sale['paid']) ?></span></div>
  <div class="d-flex justify-content-between text-danger"><span>Due</span><span><?= money($sale['due']) ?></span></div>
  <div class="d-flex justify-content-between"><span>Payment Method</span><span><?= h(ucfirst(str_replace('_',' ',$sale['payment_method']))) ?></span></div>
  <hr>
  <p class="text-center text-muted small mb-0">কেনাকাটার জন্য ধন্যবাদ! আবার আসবেন।</p>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
