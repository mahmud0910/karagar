<?php
$page_title = 'POS / Billing';
require_once __DIR__ . '/../includes/header.php';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$customers = $pdo->query("SELECT * FROM customers ORDER BY name")->fetchAll();

// Fetch products with their variants as JSON-friendly array (via JS fetch below instead for live filtering)
$products = $pdo->query("
    SELECT p.id, p.name, p.sale_price, p.image, p.category_id,
        (SELECT COALESCE(SUM(stock_qty),0) FROM product_variants WHERE product_id = p.id) as total_stock
    FROM products p WHERE p.status = 'active'
    ORDER BY p.name
")->fetchAll();
?>

<div class="row g-3">
  <!-- LEFT: Product selection -->
  <div class="col-md-7">
    <div class="card p-3">
      <div class="d-flex gap-2 mb-3">
        <input type="text" id="productSearch" class="form-control" placeholder="Product নাম লিখে খুঁজুন...">
        <select id="categoryFilter" class="form-select" style="max-width:180px;">
          <option value="">সব Category</option>
          <?php foreach ($categories as $c): ?>
            <option value="<?= $c['id'] ?>"><?= h($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="row g-2" id="productGrid" style="max-height:65vh; overflow-y:auto;">
        <?php foreach ($products as $p): ?>
        <div class="col-6 col-md-4 product-item" data-category="<?= $p['category_id'] ?>" data-name="<?= h(strtolower($p['name'])) ?>">
          <div class="card pos-product-card p-2 text-center h-100" onclick="openVariantModal(<?= $p['id'] ?>, '<?= h(addslashes($p['name'])) ?>', <?= $p['sale_price'] ?>)">
            <?php if ($p['image']): ?>
              <img src="/uploads/<?= h($p['image']) ?>" style="height:80px;object-fit:cover;border-radius:8px;" class="mb-1">
            <?php else: ?>
              <div class="bg-light d-flex align-items-center justify-content-center mb-1" style="height:80px;border-radius:8px;"><i class="bi bi-image text-muted fs-3"></i></div>
            <?php endif; ?>
            <small class="fw-semibold"><?= h($p['name']) ?></small>
            <small class="text-muted"><?= money($p['sale_price']) ?></small>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- RIGHT: Cart -->
  <div class="col-md-5">
    <div class="card p-3">
      <h5 class="mb-3"><i class="bi bi-cart4"></i> Cart</h5>

      <div class="mb-2">
        <label class="form-label small">Customer</label>
        <select id="customerSelect" class="form-select">
          <?php foreach ($customers as $c): ?>
            <option value="<?= $c['id'] ?>"><?= h($c['name']) ?> (<?= h($c['phone']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="table-responsive" style="max-height:35vh; overflow-y:auto;">
        <table class="table table-sm align-middle">
          <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th><th></th></tr></thead>
          <tbody id="cartBody"><tr><td colspan="5" class="text-center text-muted">Cart খালি</td></tr></tbody>
        </table>
      </div>

      <hr>
      <div class="d-flex justify-content-between"><span>Subtotal</span><strong id="subtotalDisplay">৳ 0.00</strong></div>
      <div class="d-flex justify-content-between align-items-center my-2">
        <span>Discount</span>
        <input type="number" id="discountInput" class="form-control form-control-sm" style="width:120px;" value="0" min="0">
      </div>
      <div class="d-flex justify-content-between fs-5"><strong>Total</strong><strong id="totalDisplay">৳ 0.00</strong></div>

      <div class="mb-2 mt-3">
        <label class="form-label small">Payment Method</label>
        <select id="paymentMethod" class="form-select">
          <option value="cash">Cash</option>
          <option value="card">Card</option>
          <option value="mobile_banking">Mobile Banking (bKash/Nagad)</option>
          <option value="due">Due (বাকি)</option>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label small">Paid Amount</label>
        <input type="number" id="paidInput" class="form-control" value="0" min="0">
      </div>

      <button class="btn btn-dark w-100 py-2" onclick="checkout()"><i class="bi bi-check-circle"></i> Complete Sale</button>
    </div>
  </div>
</div>

<!-- Variant selection modal -->
<div class="modal fade" id="variantModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="variantModalTitle">Select Variant</h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="variantModalBody">Loading...</div>
    </div>
  </div>
</div>

<script>
let cart = []; // {variant_id, name, size, color, price, qty, stock}
let currentProductId = null;
const modal = new bootstrap.Modal(document.getElementById('variantModal'));

// -------- Search / filter products --------
document.getElementById('productSearch').addEventListener('input', filterProducts);
document.getElementById('categoryFilter').addEventListener('change', filterProducts);
function filterProducts() {
  const term = document.getElementById('productSearch').value.toLowerCase();
  const cat = document.getElementById('categoryFilter').value;
  document.querySelectorAll('.product-item').forEach(el => {
    const matchesName = el.dataset.name.includes(term);
    const matchesCat = !cat || el.dataset.category === cat;
    el.style.display = (matchesName && matchesCat) ? '' : 'none';
  });
}

// -------- Open variant modal, fetch variants via AJAX --------
function openVariantModal(productId, productName, price) {
  currentProductId = productId;
  document.getElementById('variantModalTitle').textContent = productName;
  document.getElementById('variantModalBody').innerHTML = 'Loading...';
  modal.show();

  fetch('/pos/get_variants.php?product_id=' + productId)
    .then(r => r.json())
    .then(data => {
      if (!data.length) {
        document.getElementById('variantModalBody').innerHTML = '<p class="text-muted">এই প্রোডাক্টের কোনো Variant নেই। Stock যোগ করুন।</p>';
        return;
      }
      let html = '<div class="list-group">';
      data.forEach(v => {
        const disabled = v.stock_qty <= 0 ? 'disabled' : '';
        html += `<button type="button" class="list-group-item list-group-item-action d-flex justify-content-between" ${disabled}
                  onclick="addToCart(${v.id}, '${productName.replace(/'/g,"\\'")}', '${v.size||''}', '${v.color||''}', ${price}, ${v.stock_qty})">
                  <span>${v.size||'-'} / ${v.color||'-'}</span>
                  <span class="badge ${v.stock_qty<=5?'bg-danger':'bg-success'}">Stock: ${v.stock_qty}</span>
                 </button>`;
      });
      html += '</div>';
      document.getElementById('variantModalBody').innerHTML = html;
    });
}

// -------- Cart operations --------
function addToCart(variantId, name, size, color, price, stock) {
  const existing = cart.find(i => i.variant_id === variantId);
  if (existing) {
    if (existing.qty < stock) existing.qty++;
  } else {
    cart.push({variant_id: variantId, name, size, color, price, qty: 1, stock});
  }
  renderCart();
  modal.hide();
}

function removeFromCart(variantId) {
  cart = cart.filter(i => i.variant_id !== variantId);
  renderCart();
}

function changeQty(variantId, delta) {
  const item = cart.find(i => i.variant_id === variantId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) { removeFromCart(variantId); return; }
  if (item.qty > item.stock) item.qty = item.stock;
  renderCart();
}

function renderCart() {
  const body = document.getElementById('cartBody');
  if (!cart.length) {
    body.innerHTML = '<tr><td colspan="5" class="text-center text-muted">Cart খালি</td></tr>';
  } else {
    body.innerHTML = cart.map(i => `
      <tr>
        <td>${i.name}<br><small class="text-muted">${i.size||'-'} / ${i.color||'-'}</small></td>
        <td>
          <button class="btn btn-sm btn-outline-secondary" onclick="changeQty(${i.variant_id},-1)">-</button>
          ${i.qty}
          <button class="btn btn-sm btn-outline-secondary" onclick="changeQty(${i.variant_id},1)">+</button>
        </td>
        <td>৳${i.price.toFixed(2)}</td>
        <td>৳${(i.price*i.qty).toFixed(2)}</td>
        <td><button class="btn btn-sm btn-outline-danger" onclick="removeFromCart(${i.variant_id})">✕</button></td>
      </tr>
    `).join('');
  }
  updateTotals();
}

function updateTotals() {
  const subtotal = cart.reduce((s,i) => s + i.price*i.qty, 0);
  const discount = parseFloat(document.getElementById('discountInput').value) || 0;
  const total = Math.max(subtotal - discount, 0);
  document.getElementById('subtotalDisplay').textContent = '৳ ' + subtotal.toFixed(2);
  document.getElementById('totalDisplay').textContent = '৳ ' + total.toFixed(2);
}
document.getElementById('discountInput').addEventListener('input', updateTotals);

// -------- Checkout --------
function checkout() {
  if (!cart.length) { alert('Cart এ কোনো item নেই!'); return; }
  const subtotal = cart.reduce((s,i) => s + i.price*i.qty, 0);
  const discount = parseFloat(document.getElementById('discountInput').value) || 0;
  const total = Math.max(subtotal - discount, 0);
  const paid = parseFloat(document.getElementById('paidInput').value) || 0;

  const payload = {
    customer_id: document.getElementById('customerSelect').value,
    payment_method: document.getElementById('paymentMethod').value,
    discount, subtotal, total, paid,
    items: cart
  };

  fetch('/pos/checkout.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) {
      window.location.href = '/pos/invoice.php?id=' + data.sale_id;
    } else {
      alert('Error: ' + data.message);
    }
  })
  .catch(err => alert('সার্ভার এরর: ' + err));
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
