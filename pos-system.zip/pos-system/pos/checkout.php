<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_login();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['items']) || !is_array($data['items'])) {
    echo json_encode(['success' => false, 'message' => 'Cart খালি।']);
    exit;
}

$customerId = (int)($data['customer_id'] ?? 0);
$paymentMethod = $data['payment_method'] ?? 'cash';
$subtotal = (float)($data['subtotal'] ?? 0);
$discount = (float)($data['discount'] ?? 0);
$total = (float)($data['total'] ?? 0);
$paid = (float)($data['paid'] ?? 0);
$due = max($total - $paid, 0);
$status = $due > 0 ? 'due' : 'completed';

try {
    $pdo->beginTransaction();

    // Check stock availability first
    $checkStmt = $pdo->prepare("SELECT stock_qty FROM product_variants WHERE id = ? FOR UPDATE");
    foreach ($data['items'] as $item) {
        $checkStmt->execute([$item['variant_id']]);
        $row = $checkStmt->fetch();
        if (!$row || $row['stock_qty'] < $item['qty']) {
            throw new Exception('পর্যাপ্ত স্টক নেই: ' . $item['name']);
        }
    }

    $invoiceNo = generate_invoice_no($pdo);
    $saleStmt = $pdo->prepare("INSERT INTO sales (invoice_no, customer_id, user_id, subtotal, discount, total, paid, due, payment_method, status) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $saleStmt->execute([$invoiceNo, $customerId, current_user_id(), $subtotal, $discount, $total, $paid, $due, $paymentMethod, $status]);
    $saleId = $pdo->lastInsertId();

    $itemStmt = $pdo->prepare("INSERT INTO sale_items (sale_id, variant_id, product_name, size, color, qty, price, line_total) VALUES (?,?,?,?,?,?,?,?)");
    $stockStmt = $pdo->prepare("UPDATE product_variants SET stock_qty = stock_qty - ? WHERE id = ?");

    foreach ($data['items'] as $item) {
        $lineTotal = $item['price'] * $item['qty'];
        $itemStmt->execute([$saleId, $item['variant_id'], $item['name'], $item['size'], $item['color'], $item['qty'], $item['price'], $lineTotal]);
        $stockStmt->execute([$item['qty'], $item['variant_id']]);
    }

    // Update customer due balance if any
    if ($due > 0) {
        $custStmt = $pdo->prepare("UPDATE customers SET total_due = total_due + ? WHERE id = ?");
        $custStmt->execute([$due, $customerId]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'sale_id' => $saleId, 'invoice_no' => $invoiceNo]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
