# Clothing Brand POS System (Plain PHP + MySQL)

আপনার clothing brand এর জন্য একটা সম্পূর্ণ POS (Point of Sale) সিস্টেম।

## ✨ ফিচার সমূহ
- **Product / Stock Management** — Size, Color সহ প্রতিটি প্রোডাক্টের ভ্যারিয়েন্ট এবং স্টক ম্যানেজমেন্ট
- **Billing / POS Screen** — দ্রুত বিক্রি, Cart, Invoice প্রিন্ট
- **Customer Management** — কাস্টমার তালিকা, কেনাকাটার ইতিহাস, বাকি (Due) ট্র্যাকিং
- **Staff Login (Admin/Cashier)** — Role অনুযায়ী Access কন্ট্রোল
- **Customer Messaging** — সবাইকে অথবা একজনকে SMS/Email পাঠানোর সিস্টেম (Gateway যুক্ত করার জায়গা করা আছে)
- **Dashboard** — আজকের বিক্রি, মাসিক বিক্রি, Low stock alert
- **Sales History & Reports**

---

## 🚀 Setup (Online Hosting এ আপলোড করার নিয়ম)

### ধাপ ১: Hosting এ ফাইল আপলোড করুন
1. cPanel / hosting file manager এ যান, অথবা FTP ব্যবহার করুন (FileZilla)
2. এই পুরো ফোল্ডারের সব ফাইল আপনার হোস্টিং এর `public_html/` (বা root) ফোল্ডারে আপলোড করুন

### ধাপ ২: Database তৈরি করুন
1. cPanel থেকে **MySQL Database Wizard** এ গিয়ে একটা নতুন database বানান (যেমন: `clothing_pos`)
2. একটা database user বানান এবং database এর সাথে যুক্ত করুন (সব permission দিন)
3. **phpMyAdmin** এ ঢুকে সেই database সিলেক্ট করুন
4. **Import** ট্যাবে গিয়ে `database.sql` ফাইলটি import করুন — এতে সব টেবিল ও স্যাম্পল ডাটা তৈরি হয়ে যাবে

### ধাপ ৩: Database Connection বসান
`config/database.php` ফাইলটি খুলে নিচের তথ্য আপনার hosting এর database তথ্য দিয়ে বদলে দিন:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');
```

### ধাপ ৪: Admin একাউন্ট তৈরি করুন
1. ব্রাউজারে যান: `https://yourdomain.com/create_admin.php`
2. আপনার নাম, real email, ও password দিয়ে ফর্ম পূরণ করুন
3. Submit করার পর **এই ফাইলটি (`create_admin.php`) সার্ভার থেকে ডিলিট করে দিন** — নিরাপত্তার জন্য এটা জরুরি

### ধাপ ৫: Login করুন
`https://yourdomain.com/login.php` এ গিয়ে নতুন তৈরি করা admin একাউন্ট দিয়ে লগইন করুন।

---

## 📱 SMS/Email পাঠানো চালু করবেন কিভাবে?
এই মুহূর্তে Message ফিচারটি শুধু ডাটাবেজে log রাখে (demo mode), আসল SMS/Email পাঠায় না।
আসল SMS পাঠাতে `includes/messaging.php` ফাইল খুলে আপনার SMS gateway (যেমন: Alpha SMS, BulkSMSBD ইত্যাদি) এর API যুক্ত করুন — ফাইলের ভিতরে বিস্তারিত নির্দেশনা কমেন্ট আকারে দেওয়া আছে।

---

## 🖼️ Product ছবির জন্য
প্রোডাক্ট এর ছবি `uploads/` ফোল্ডারে সেভ হয়। নিশ্চিত করুন এই ফোল্ডারে write permission (755 বা 775) আছে।

---

## 🔐 নিরাপত্তার জন্য গুরুত্বপূর্ণ
- `create_admin.php` ব্যবহারের পর অবশ্যই ডিলিট করুন
- `config/database.php` এর তথ্য কখনো public করবেন না
- নিয়মিত database backup রাখুন (phpMyAdmin থেকে Export করা যায়)

---

## 🗂️ Folder Structure
```
config/database.php     -> DB connection
includes/                -> shared header, footer, auth, functions
products/                -> Product & stock management
pos/                      -> Billing screen, checkout, invoice
customers/                -> Customer management
sales/history.php         -> Sales report
messages/send.php         -> SMS/Email messaging
users/                    -> Staff management (Admin only)
uploads/                  -> Product images
database.sql              -> Full DB schema, import this first
create_admin.php          -> One-time setup, delete after use
```

কোনো প্রশ্ন থাকলে বা নতুন ফিচার (যেমন: Barcode print, Supplier management, Purchase/Stock-in module, PDF invoice, Multi-branch) লাগলে জানাবেন — এই সিস্টেমে যোগ করে দেওয়া যাবে।
