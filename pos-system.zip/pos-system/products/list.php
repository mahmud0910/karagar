<?php
$page_title = 'Products';
require_once __DIR__ . '/../includes/header.php';

$search = trim($_GET['q'] ?? '');
$sql = "SELECT p.*, c.name as category_name,
        (SELECT COALESCE(SUM(stock_qty),0) FROM product_variants WHERE product_id = p.id) as total_stock
        FROM products p LEFT JOIN categories c ON c.id = p.category_id";
$params = [];
if ($search !== '') {
    $sql .= " WHERE p.name LIKE ?";
    $params[] = "%$search%";
}
$sql .= " ORDER BY p.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4>Products</h4>
  <a href="/products/add.php" class="btn btn-dark"><i class="bi bi-plus-circle"></i> নতুন Product</a>
</div>

<div class="card p-3">
  <form method="GET" class="mb-3">
    <div class="input-group" style="max-width:350px;">
      <input type="text" name="q" class="form-control" placeholder="Product খুঁজুন..." value="<?= h($search) ?>">
      <button class="btn btn-outline-dark"><i class="bi bi-search"></i></button>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead>
        <tr><th>Image</th><th>Name</th><th>Category</th><th>Sale Price</th><th>Total Stock</th><th>Status</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php foreach ($products as $p): ?>
        <tr>
          <td>
            <?php if ($p['image']): ?>
              <img src="/uploads/<?= h($p['image']) ?>" width="45" height="45" style="object-fit:cover;border-radius:6px;">
            <?php else: ?>
              <div class="bg-light d-flex align-items-center justify-content-center" style="width:45px;height:45px;border-radius:6px;"><i class="bi bi-image text-muted"></i></div>
            <?php endif; ?>
          </td>
          <td><?= h($p['name']) ?></td>
          <td><?= h($p['category_name'] ?? '-') ?></td>
          <td><?= money($p['sale_price']) ?></td>
          <td>
            <span class="badge <?= $p['total_stock'] <= 5 ? 'bg-danger' : 'bg-success' ?>"><?= $p['total_stock'] ?></span>
          </td>
          <td>
            <span class="badge <?= $p['status']=='active' ? 'bg-success' : 'bg-secondary' ?>"><?= h($p['status']) ?></span>
          </td>
          <td>
            <a href="/products/edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
            <a href="/products/delete.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('এই প্রোডাক্ট ডিলিট করবেন?');"><i class="bi bi-trash"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($products)): ?>
          <tr><td colspan="7" class="text-center text-muted">কোনো প্রোডাক্ট নেই</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
