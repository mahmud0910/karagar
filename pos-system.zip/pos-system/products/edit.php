<?php
$page_title = 'Edit Product';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$product = $stmt->fetch();
if (!$product) { die('Product পাওয়া যায়নি।'); }

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

$vStmt = $pdo->prepare("SELECT * FROM product_variants WHERE product_id = ?");
$vStmt->execute([$id]);
$variants = $vStmt->fetchAll();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = $_POST['category_id'] ?: null;
    $description = trim($_POST['description'] ?? '');
    $purchase_price = (float)($_POST['purchase_price'] ?? 0);
    $sale_price = (float)($_POST['sale_price'] ?? 0);
    $status = $_POST['status'] ?? 'active';
    $variant_ids = $_POST['variant_id'] ?? [];
    $sizes = $_POST['size'] ?? [];
    $colors = $_POST['color'] ?? [];
    $stocks = $_POST['stock_qty'] ?? [];

    if ($name === '' || $sale_price <= 0) {
        $error = 'Product Name এবং Sale Price অবশ্যই দিতে হবে।';
    } else {
        $imageName = $product['image'];
        if (!empty($_FILES['image']['name'])) {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $imageName = uniqid('prod_') . '.' . $ext;
            $uploadDir = __DIR__ . '/../uploads/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("UPDATE products SET category_id=?, name=?, description=?, purchase_price=?, sale_price=?, image=?, status=? WHERE id=?");
            $stmt->execute([$category_id, $name, $description, $purchase_price, $sale_price, $imageName, $status, $id]);

            // Update existing variants
            $uStmt = $pdo->prepare("UPDATE product_variants SET size=?, color=?, stock_qty=? WHERE id=? AND product_id=?");
            $insStmt = $pdo->prepare("INSERT INTO product_variants (product_id, size, color, sku, stock_qty) VALUES (?,?,?,?,?)");

            foreach ($sizes as $i => $size) {
                $color = $colors[$i] ?? '';
                $qty = (int)($stocks[$i] ?? 0);
                $vid = $variant_ids[$i] ?? '';
                if ($size === '' && $color === '') continue;

                if ($vid !== '' && $vid !== 'new') {
                    $uStmt->execute([$size, $color, $qty, $vid, $id]);
                } else {
                    $sku = 'SKU-' . $id . '-' . strtoupper(substr($size,0,3)) . '-' . strtoupper(substr($color,0,3)) . '-' . rand(100,999);
                    $insStmt->execute([$id, $size, $color, $sku, $qty]);
                }
            }
            $pdo->commit();
            redirect_with_message('/products/list.php', 'success', 'Product আপডেট হয়েছে।');
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'সমস্যা হয়েছে: ' . $e->getMessage();
        }
    }
}
?>

<h4 class="mb-3">Product Edit করুন</h4>
<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="card p-4">
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Product Name *</label>
      <input type="text" name="name" class="form-control" value="<?= h($product['name']) ?>" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Category</label>
      <select name="category_id" class="form-select">
        <option value="">-- Select --</option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $c['id']==$product['category_id']?'selected':'' ?>><?= h($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Purchase Price</label>
      <input type="number" step="0.01" name="purchase_price" class="form-control" value="<?= h($product['purchase_price']) ?>">
    </div>
    <div class="col-md-4">
      <label class="form-label">Sale Price *</label>
      <input type="number" step="0.01" name="sale_price" class="form-control" value="<?= h($product['sale_price']) ?>" required>
    </div>
    <div class="col-md-4">
      <label class="form-label">Status</label>
      <select name="status" class="form-select">
        <option value="active" <?= $product['status']=='active'?'selected':'' ?>>Active</option>
        <option value="inactive" <?= $product['status']=='inactive'?'selected':'' ?>>Inactive</option>
      </select>
    </div>
    <?php if ($product['image']): ?>
    <div class="col-md-2">
      <label class="form-label">Current Image</label><br>
      <img src="/uploads/<?= h($product['image']) ?>" width="60" height="60" style="object-fit:cover;border-radius:6px;">
    </div>
    <?php endif; ?>
    <div class="col-md-6">
      <label class="form-label">Change Image (optional)</label>
      <input type="file" name="image" class="form-control" accept="image/*">
    </div>
    <div class="col-12">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="2"><?= h($product['description']) ?></textarea>
    </div>
  </div>

  <hr class="my-4">
  <h6>Size / Color / Stock (Variants)</h6>

  <div id="variantRows">
    <?php foreach ($variants as $v): ?>
    <div class="row g-2 mb-2 variant-row">
      <input type="hidden" name="variant_id[]" value="<?= $v['id'] ?>">
      <div class="col-md-4"><input type="text" name="size[]" class="form-control" value="<?= h($v['size']) ?>" placeholder="Size"></div>
      <div class="col-md-4"><input type="text" name="color[]" class="form-control" value="<?= h($v['color']) ?>" placeholder="Color"></div>
      <div class="col-md-3"><input type="number" name="stock_qty[]" class="form-control" value="<?= h($v['stock_qty']) ?>" placeholder="Stock Qty"></div>
      <div class="col-md-1"><button type="button" class="btn btn-outline-danger removeRow">✕</button></div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($variants)): ?>
    <div class="row g-2 mb-2 variant-row">
      <input type="hidden" name="variant_id[]" value="new">
      <div class="col-md-4"><input type="text" name="size[]" class="form-control" placeholder="Size"></div>
      <div class="col-md-4"><input type="text" name="color[]" class="form-control" placeholder="Color"></div>
      <div class="col-md-3"><input type="number" name="stock_qty[]" class="form-control" value="0" placeholder="Stock Qty"></div>
      <div class="col-md-1"><button type="button" class="btn btn-outline-danger removeRow">✕</button></div>
    </div>
    <?php endif; ?>
  </div>
  <button type="button" id="addRow" class="btn btn-sm btn-outline-dark mb-3"><i class="bi bi-plus"></i> আরেকটি Variant যোগ করুন</button>

  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-dark">Update Product</button>
    <a href="/products/list.php" class="btn btn-secondary">Cancel</a>
  </div>
</form>

<script>
document.getElementById('addRow').addEventListener('click', function() {
  const row = document.querySelector('.variant-row').cloneNode(true);
  row.querySelectorAll('input[type=text],input[type=number]').forEach(i => i.value = i.name === 'stock_qty[]' ? 0 : '');
  row.querySelector('input[type=hidden]').value = 'new';
  document.getElementById('variantRows').appendChild(row);
});
document.getElementById('variantRows').addEventListener('click', function(e) {
  if (e.target.classList.contains('removeRow')) {
    const rows = document.querySelectorAll('.variant-row');
    if (rows.length > 1) e.target.closest('.variant-row').remove();
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
