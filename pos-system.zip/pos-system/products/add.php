<?php
$page_title = 'Add Product';
require_once __DIR__ . '/../includes/header.php';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = $_POST['category_id'] ?: null;
    $description = trim($_POST['description'] ?? '');
    $purchase_price = (float)($_POST['purchase_price'] ?? 0);
    $sale_price = (float)($_POST['sale_price'] ?? 0);
    $sizes = $_POST['size'] ?? [];
    $colors = $_POST['color'] ?? [];
    $stocks = $_POST['stock_qty'] ?? [];

    if ($name === '' || $sale_price <= 0) {
        $error = 'Product Name এবং Sale Price অবশ্যই দিতে হবে।';
    } else {
        // handle image upload (optional)
        $imageName = null;
        if (!empty($_FILES['image']['name'])) {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $imageName = uniqid('prod_') . '.' . $ext;
            $uploadDir = __DIR__ . '/../uploads/';
            if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
        }

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO products (category_id, name, description, purchase_price, sale_price, image) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$category_id, $name, $description, $purchase_price, $sale_price, $imageName]);
            $productId = $pdo->lastInsertId();

            $vStmt = $pdo->prepare("INSERT INTO product_variants (product_id, size, color, sku, stock_qty) VALUES (?,?,?,?,?)");
            foreach ($sizes as $i => $size) {
                $color = $colors[$i] ?? '';
                $qty = (int)($stocks[$i] ?? 0);
                if ($size === '' && $color === '') continue; // skip empty rows
                $sku = 'SKU-' . $productId . '-' . strtoupper(substr($size,0,3)) . '-' . strtoupper(substr($color,0,3)) . '-' . rand(100,999);
                $vStmt->execute([$productId, $size, $color, $sku, $qty]);
            }
            $pdo->commit();
            redirect_with_message('/products/list.php', 'success', 'Product যোগ করা হয়েছে।');
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'সমস্যা হয়েছে: ' . $e->getMessage();
        }
    }
}
?>

<h4 class="mb-3">নতুন Product যোগ করুন</h4>

<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="card p-4">
  <div class="row g-3">
    <div class="col-md-6">
      <label class="form-label">Product Name *</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="col-md-6">
      <label class="form-label">Category</label>
      <select name="category_id" class="form-select">
        <option value="">-- Select --</option>
        <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>"><?= h($c['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label">Purchase Price</label>
      <input type="number" step="0.01" name="purchase_price" class="form-control" value="0">
    </div>
    <div class="col-md-4">
      <label class="form-label">Sale Price *</label>
      <input type="number" step="0.01" name="sale_price" class="form-control" required>
    </div>
    <div class="col-md-4">
      <label class="form-label">Product Image</label>
      <input type="file" name="image" class="form-control" accept="image/*">
    </div>
    <div class="col-12">
      <label class="form-label">Description</label>
      <textarea name="description" class="form-control" rows="2"></textarea>
    </div>
  </div>

  <hr class="my-4">
  <h6>Size / Color / Stock (Variants)</h6>
  <p class="text-muted small">একই প্রোডাক্টের ভিন্ন Size ও Color এর জন্য আলাদা আলাদা row যোগ করুন। যেমন: Red-M, Red-L, Blue-M ইত্যাদি।</p>

  <div id="variantRows">
    <div class="row g-2 mb-2 variant-row">
      <div class="col-md-4"><input type="text" name="size[]" class="form-control" placeholder="Size (M, L, XL...)"></div>
      <div class="col-md-4"><input type="text" name="color[]" class="form-control" placeholder="Color (Red, Blue...)"></div>
      <div class="col-md-3"><input type="number" name="stock_qty[]" class="form-control" placeholder="Stock Qty" value="0"></div>
      <div class="col-md-1"><button type="button" class="btn btn-outline-danger removeRow">✕</button></div>
    </div>
  </div>
  <button type="button" id="addRow" class="btn btn-sm btn-outline-dark mb-3"><i class="bi bi-plus"></i> আরেকটি Variant যোগ করুন</button>

  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-dark">Save Product</button>
    <a href="/products/list.php" class="btn btn-secondary">Cancel</a>
  </div>
</form>

<script>
document.getElementById('addRow').addEventListener('click', function() {
  const row = document.querySelector('.variant-row').cloneNode(true);
  row.querySelectorAll('input').forEach(i => i.value = i.name === 'stock_qty[]' ? 0 : '');
  document.getElementById('variantRows').appendChild(row);
});
document.getElementById('variantRows').addEventListener('click', function(e) {
  if (e.target.classList.contains('removeRow')) {
    const rows = document.querySelectorAll('.variant-row');
    if (rows.length > 1) e.target.closest('.variant-row').remove();
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
