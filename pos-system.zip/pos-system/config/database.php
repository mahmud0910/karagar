<?php
/**
 * Database connection (PDO)
 * -------------------------
 * Online hosting এ upload করার পর নিচের ৪টা value বদলে দিন
 * (cPanel / hosting control panel থেকে পাবেন)
 */

define('DB_HOST', 'localhost');       // usually 'localhost'
define('DB_NAME', 'clothing_pos');    // your database name
define('DB_USER', 'root');            // your database username
define('DB_PASS', '');                // your database password

// Site settings
define('SITE_NAME', 'My Clothing POS');
define('CURRENCY', '৳'); // Taka symbol, change if needed

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
