<?php
/**
 * =====================================================================
 * ONE-TIME SETUP SCRIPT — creates/resets the admin login.
 * 1) Upload this file along with the rest of the project.
 * 2) Visit it once in your browser: yourdomain.com/create_admin.php
 * 3) Fill the form to set your real admin email & password.
 * 4) DELETE this file from the server immediately after use — it is a
 *    security risk to leave it online.
 * =====================================================================
 */
require_once __DIR__ . '/config/database.php';

$done = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name && $email && strlen($password) >= 6) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        // remove old admin with same email if exists, then insert fresh
        $stmt = $pdo->prepare("DELETE FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'admin')");
        $stmt->execute([$name, $email, $hash]);
        $done = true;
    } else {
        $error = 'সব ফিল্ড পূরণ করুন। Password কমপক্ষে ৬ ক্যারেক্টার হতে হবে।';
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<title>Setup Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark d-flex align-items-center" style="min-height:100vh;">
<div class="container">
<div class="row justify-content-center">
<div class="col-md-5">
<div class="card p-4">
<h4 class="mb-3">Admin Account Setup</h4>
<?php if ($done): ?>
  <div class="alert alert-success">
    Admin account তৈরি হয়েছে! এখন <a href="/login.php">Login page</a> এ গিয়ে লগইন করুন।
    <br><strong>এই ফাইলটি (create_admin.php) এখনই সার্ভার থেকে ডিলিট করে দিন।</strong>
  </div>
<?php else: ?>
  <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="POST">
    <div class="mb-3"><label class="form-label">Your Name</label><input class="form-control" name="name" required></div>
    <div class="mb-3"><label class="form-label">Admin Email</label><input type="email" class="form-control" name="email" required></div>
    <div class="mb-3"><label class="form-label">Password</label><input type="password" class="form-control" name="password" required minlength="6"></div>
    <button class="btn btn-dark w-100">Create Admin</button>
  </form>
<?php endif; ?>
</div></div></div></div>
</body>
</html>
