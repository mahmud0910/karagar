<?php
$page_title = 'Edit Customer';
require_once __DIR__ . '/../includes/header.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->execute([$id]);
$customer = $stmt->fetch();
if (!$customer) { die('Customer পাওয়া যায়নি।'); }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($name === '' || $phone === '') {
        $error = 'Name এবং Phone অবশ্যই দিতে হবে।';
    } else {
        $stmt = $pdo->prepare("UPDATE customers SET name=?, phone=?, email=?, address=? WHERE id=?");
        $stmt->execute([$name, $phone, $email ?: null, $address ?: null, $id]);
        redirect_with_message('/customers/list.php', 'success', 'Customer আপডেট হয়েছে।');
    }
}

// Purchase history
$histStmt = $pdo->prepare("SELECT * FROM sales WHERE customer_id = ? ORDER BY id DESC LIMIT 10");
$histStmt->execute([$id]);
$history = $histStmt->fetchAll();
?>
<h4 class="mb-3">Customer Edit করুন</h4>
<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>

<div class="row g-3">
  <div class="col-md-5">
    <form method="POST" class="card p-4">
      <div class="mb-3"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" value="<?= h($customer['name']) ?>" required></div>
      <div class="mb-3"><label class="form-label">Phone *</label><input type="text" name="phone" class="form-control" value="<?= h($customer['phone']) ?>" required></div>
      <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control" value="<?= h($customer['email']) ?>"></div>
      <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"><?= h($customer['address']) ?></textarea></div>
      <div class="mb-3"><strong>Total Due:</strong> <?= money($customer['total_due']) ?></div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-dark">Update</button>
        <a href="/customers/list.php" class="btn btn-secondary">Cancel</a>
      </div>
    </form>
  </div>
  <div class="col-md-7">
    <div class="card p-3">
      <h6>সাম্প্রতিক কেনাকাটা</h6>
      <table class="table table-sm">
        <thead><tr><th>Invoice</th><th>Total</th><th>Due</th><th>Date</th></tr></thead>
        <tbody>
          <?php foreach ($history as $h): ?>
          <tr>
            <td><a href="/pos/invoice.php?id=<?= $h['id'] ?>"><?= h($h['invoice_no']) ?></a></td>
            <td><?= money($h['total']) ?></td>
            <td><?= money($h['due']) ?></td>
            <td><?= date('d M Y', strtotime($h['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($history)): ?><tr><td colspan="4" class="text-center text-muted">কোনো কেনাকাটার ইতিহাস নেই</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
