<?php
$page_title = 'Add Customer';
require_once __DIR__ . '/../includes/header.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($name === '' || $phone === '') {
        $error = 'Name এবং Phone অবশ্যই দিতে হবে।';
    } else {
        $stmt = $pdo->prepare("INSERT INTO customers (name, phone, email, address) VALUES (?,?,?,?)");
        $stmt->execute([$name, $phone, $email ?: null, $address ?: null]);
        redirect_with_message('/customers/list.php', 'success', 'Customer যোগ করা হয়েছে।');
    }
}
?>
<h4 class="mb-3">নতুন Customer যোগ করুন</h4>
<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
<form method="POST" class="card p-4" style="max-width:500px;">
  <div class="mb-3"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" required></div>
  <div class="mb-3"><label class="form-label">Phone *</label><input type="text" name="phone" class="form-control" required></div>
  <div class="mb-3"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
  <div class="mb-3"><label class="form-label">Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-dark">Save</button>
    <a href="/customers/list.php" class="btn btn-secondary">Cancel</a>
  </div>
</form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
