<?php
$page_title = 'Customers';
require_once __DIR__ . '/../includes/header.php';

$search = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM customers";
$params = [];
if ($search !== '') {
    $sql .= " WHERE name LIKE ? OR phone LIKE ?";
    $params = ["%$search%", "%$search%"];
}
$sql .= " ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$customers = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4>Customers</h4>
  <a href="/customers/add.php" class="btn btn-dark"><i class="bi bi-person-plus"></i> নতুন Customer</a>
</div>

<div class="card p-3">
  <form method="GET" class="mb-3">
    <div class="input-group" style="max-width:350px;">
      <input type="text" name="q" class="form-control" placeholder="নাম বা ফোন নম্বর দিয়ে খুঁজুন..." value="<?= h($search) ?>">
      <button class="btn btn-outline-dark"><i class="bi bi-search"></i></button>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Total Due</th><th>Joined</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($customers as $c): ?>
        <tr>
          <td><?= h($c['name']) ?></td>
          <td><?= h($c['phone']) ?></td>
          <td><?= h($c['email'] ?? '-') ?></td>
          <td><span class="badge <?= $c['total_due']>0 ? 'bg-danger':'bg-success' ?>"><?= money($c['total_due']) ?></span></td>
          <td><?= date('d M Y', strtotime($c['created_at'])) ?></td>
          <td>
            <a href="/customers/edit.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
            <a href="/messages/send.php?customer_id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-info"><i class="bi bi-chat-dots"></i></a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($customers)): ?>
          <tr><td colspan="6" class="text-center text-muted">কোনো কাস্টমার নেই</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
