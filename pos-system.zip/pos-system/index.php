<?php
$page_title = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

// Today's sales
$today = date('Y-m-d');
$stmt = $pdo->prepare("SELECT COALESCE(SUM(total),0) as total, COUNT(*) as cnt FROM sales WHERE DATE(created_at) = ? AND status != 'cancelled'");
$stmt->execute([$today]);
$todaySales = $stmt->fetch();

// This month's sales
$monthStart = date('Y-m-01');
$stmt = $pdo->prepare("SELECT COALESCE(SUM(total),0) as total FROM sales WHERE created_at >= ? AND status != 'cancelled'");
$stmt->execute([$monthStart]);
$monthSales = $stmt->fetch();

// Total products / low stock
$totalProducts = $pdo->query("SELECT COUNT(*) as cnt FROM products WHERE status='active'")->fetch()['cnt'];
$lowStock = $pdo->query("SELECT COUNT(*) as cnt FROM product_variants WHERE stock_qty <= 5")->fetch()['cnt'];
$totalCustomers = $pdo->query("SELECT COUNT(*) as cnt FROM customers")->fetch()['cnt'];

// Recent sales
$recentSales = $pdo->query("
    SELECT s.*, c.name as customer_name, u.name as staff_name
    FROM sales s
    JOIN customers c ON c.id = s.customer_id
    JOIN users u ON u.id = s.user_id
    ORDER BY s.id DESC LIMIT 8
")->fetchAll();

// Low stock list
$lowStockList = $pdo->query("
    SELECT p.name, pv.size, pv.color, pv.stock_qty
    FROM product_variants pv
    JOIN products p ON p.id = pv.product_id
    WHERE pv.stock_qty <= 5
    ORDER BY pv.stock_qty ASC LIMIT 6
")->fetchAll();
?>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="stat-card bg-purple">
      <p>আজকের বিক্রি (<?= $todaySales['cnt'] ?> Sales)</p>
      <h3><?= money($todaySales['total']) ?></h3>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card bg-teal">
      <p>এই মাসের বিক্রি</p>
      <h3><?= money($monthSales['total']) ?></h3>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card bg-orange">
      <p>মোট প্রোডাক্ট</p>
      <h3><?= $totalProducts ?></h3>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card bg-pink">
      <p>মোট কাস্টমার</p>
      <h3><?= $totalCustomers ?></h3>
    </div>
  </div>
</div>

<div class="row g-3">
  <div class="col-md-8">
    <div class="card p-3">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="mb-0">সাম্প্রতিক বিক্রি</h5>
        <a href="/sales/history.php" class="btn btn-sm btn-outline-dark">সব দেখুন</a>
      </div>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead><tr><th>Invoice</th><th>Customer</th><th>Staff</th><th>Total</th><th>Time</th></tr></thead>
          <tbody>
            <?php foreach ($recentSales as $s): ?>
            <tr>
              <td><a href="/pos/invoice.php?id=<?= $s['id'] ?>"><?= h($s['invoice_no']) ?></a></td>
              <td><?= h($s['customer_name']) ?></td>
              <td><?= h($s['staff_name']) ?></td>
              <td><?= money($s['total']) ?></td>
              <td><?= date('d M, h:i A', strtotime($s['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($recentSales)): ?>
              <tr><td colspan="5" class="text-center text-muted">এখনো কোনো বিক্রি হয়নি</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="card p-3">
      <h5 class="mb-3"><i class="bi bi-exclamation-triangle text-danger"></i> স্টক কম (Low Stock)</h5>
      <?php if ($lowStockList): ?>
        <ul class="list-group">
          <?php foreach ($lowStockList as $l): ?>
            <li class="list-group-item d-flex justify-content-between">
              <span><?= h($l['name']) ?> <small class="text-muted">(<?= h($l['size']) ?>/<?= h($l['color']) ?>)</small></span>
              <span class="badge bg-danger"><?= $l['stock_qty'] ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="text-muted">সব প্রোডাক্টে পর্যাপ্ত স্টক আছে।</p>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
