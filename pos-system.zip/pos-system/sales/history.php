<?php
$page_title = 'Sales History';
require_once __DIR__ . '/../includes/header.php';

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

$stmt = $pdo->prepare("
    SELECT s.*, c.name as customer_name, u.name as staff_name
    FROM sales s JOIN customers c ON c.id = s.customer_id JOIN users u ON u.id = s.user_id
    WHERE DATE(s.created_at) BETWEEN ? AND ?
    ORDER BY s.id DESC
");
$stmt->execute([$from, $to]);
$sales = $stmt->fetchAll();

$totalAmount = array_sum(array_column($sales, 'total'));
$totalDue = array_sum(array_column($sales, 'due'));
?>

<h4 class="mb-3">Sales History</h4>

<div class="card p-3 mb-3">
  <form method="GET" class="row g-2 align-items-end">
    <div class="col-auto">
      <label class="form-label small">From</label>
      <input type="date" name="from" class="form-control" value="<?= h($from) ?>">
    </div>
    <div class="col-auto">
      <label class="form-label small">To</label>
      <input type="date" name="to" class="form-control" value="<?= h($to) ?>">
    </div>
    <div class="col-auto">
      <button class="btn btn-dark">Filter</button>
    </div>
  </form>
</div>

<div class="row g-3 mb-3">
  <div class="col-md-4">
    <div class="stat-card bg-purple"><p>Total Sales</p><h3><?= count($sales) ?></h3></div>
  </div>
  <div class="col-md-4">
    <div class="stat-card bg-teal"><p>Total Amount</p><h3><?= money($totalAmount) ?></h3></div>
  </div>
  <div class="col-md-4">
    <div class="stat-card bg-orange"><p>Total Due</p><h3><?= money($totalDue) ?></h3></div>
  </div>
</div>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead><tr><th>Invoice</th><th>Customer</th><th>Staff</th><th>Total</th><th>Paid</th><th>Due</th><th>Method</th><th>Date</th></tr></thead>
      <tbody>
        <?php foreach ($sales as $s): ?>
        <tr>
          <td><a href="/pos/invoice.php?id=<?= $s['id'] ?>"><?= h($s['invoice_no']) ?></a></td>
          <td><?= h($s['customer_name']) ?></td>
          <td><?= h($s['staff_name']) ?></td>
          <td><?= money($s['total']) ?></td>
          <td><?= money($s['paid']) ?></td>
          <td><?= $s['due']>0 ? '<span class="text-danger">'.money($s['due']).'</span>' : money(0) ?></td>
          <td><?= h(ucfirst(str_replace('_',' ',$s['payment_method']))) ?></td>
          <td><?= date('d M Y, h:i A', strtotime($s['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($sales)): ?><tr><td colspan="8" class="text-center text-muted">কোনো বিক্রি পাওয়া যায়নি</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
