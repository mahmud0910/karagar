<?php
$page_title = 'Add Staff';
require_once __DIR__ . '/../includes/header.php';
require_admin();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $role = $_POST['role'] ?? 'cashier';
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || strlen($password) < 6) {
        $error = 'সব ফিল্ড ঠিকভাবে পূরণ করুন। Password কমপক্ষে ৬ ক্যারেক্টার।';
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'এই Email দিয়ে আগে থেকেই একজন Staff আছে।';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)");
            $stmt->execute([$name, $email, $hash, $role, $phone ?: null]);
            redirect_with_message('/users/list.php', 'success', 'Staff যোগ করা হয়েছে।');
        }
    }
}
?>
<h4 class="mb-3">নতুন Staff যোগ করুন</h4>
<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
<form method="POST" class="card p-4" style="max-width:500px;">
  <div class="mb-3"><label class="form-label">Name *</label><input type="text" name="name" class="form-control" required></div>
  <div class="mb-3"><label class="form-label">Email *</label><input type="email" name="email" class="form-control" required></div>
  <div class="mb-3"><label class="form-label">Phone</label><input type="text" name="phone" class="form-control"></div>
  <div class="mb-3">
    <label class="form-label">Role *</label>
    <select name="role" class="form-select">
      <option value="cashier">Cashier</option>
      <option value="admin">Admin</option>
    </select>
  </div>
  <div class="mb-3"><label class="form-label">Password *</label><input type="password" name="password" class="form-control" minlength="6" required></div>
  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-dark">Save</button>
    <a href="/users/list.php" class="btn btn-secondary">Cancel</a>
  </div>
</form>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
