<?php
$page_title = 'Staff Management';
require_once __DIR__ . '/../includes/header.php';
require_admin();

$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4>Staff Management</h4>
  <a href="/users/add.php" class="btn btn-dark"><i class="bi bi-person-plus"></i> নতুন Staff</a>
</div>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table table-hover align-middle">
      <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Phone</th><th>Status</th><th>Joined</th><th>Action</th></tr></thead>
      <tbody>
        <?php foreach ($users as $u): ?>
        <tr>
          <td><?= h($u['name']) ?></td>
          <td><?= h($u['email']) ?></td>
          <td><span class="badge <?= $u['role']=='admin'?'bg-dark':'bg-info' ?>"><?= h($u['role']) ?></span></td>
          <td><?= h($u['phone'] ?? '-') ?></td>
          <td><span class="badge <?= $u['status']=='active'?'bg-success':'bg-secondary' ?>"><?= h($u['status']) ?></span></td>
          <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          <td>
            <?php if ($u['id'] != current_user_id()): ?>
            <a href="/users/toggle_status.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-warning" onclick="return confirm('স্ট্যাটাস পরিবর্তন করবেন?')">
              <?= $u['status']=='active' ? 'Deactivate' : 'Activate' ?>
            </a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
