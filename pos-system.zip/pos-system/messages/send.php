<?php
$page_title = 'Send Message';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/messaging.php';

$customers = $pdo->query("SELECT * FROM customers WHERE phone != '0000000000' ORDER BY name")->fetchAll();
$preselect = (int)($_GET['customer_id'] ?? 0);

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $target = $_POST['target'] ?? 'single'; // single | all
    $customerId = (int)($_POST['customer_id'] ?? 0);
    $channel = $_POST['channel'] ?? 'sms';
    $message = trim($_POST['message'] ?? '');

    if ($message === '') {
        $error = 'মেসেজ লিখুন।';
    } else {
        if ($target === 'all') {
            $recipients = $pdo->query("SELECT * FROM customers WHERE phone != '0000000000'")->fetchAll();
        } else {
            if (!$customerId) {
                $error = 'একজন Customer সিলেক্ট করুন।';
            } else {
                $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
                $stmt->execute([$customerId]);
                $recipients = $stmt->fetchAll();
            }
        }

        if (!$error && !empty($recipients)) {
            $sentCount = 0;
            foreach ($recipients as $r) {
                if ($channel === 'sms' || $channel === 'both') {
                    send_sms_via_gateway($r['phone'], $message);
                }
                if (($channel === 'email' || $channel === 'both') && $r['email']) {
                    send_email_via_gateway($r['email'], SITE_NAME . ' থেকে বার্তা', $message);
                }
                $sentCount++;
            }

            $logStmt = $pdo->prepare("INSERT INTO customer_messages (sent_by, customer_id, message, channel, recipient_count) VALUES (?,?,?,?,?)");
            $logStmt->execute([
                current_user_id(),
                $target === 'all' ? null : $customerId,
                $message,
                $channel,
                $sentCount
            ]);

            $success = "$sentCount জন কাস্টমারকে মেসেজ পাঠানো হয়েছে।";
        } elseif (!$error) {
            $error = 'কোনো Recipient পাওয়া যায়নি।';
        }
    }
}

// Message history
$history = $pdo->query("
    SELECT cm.*, u.name as sender_name, c.name as customer_name
    FROM customer_messages cm
    JOIN users u ON u.id = cm.sent_by
    LEFT JOIN customers c ON c.id = cm.customer_id
    ORDER BY cm.id DESC LIMIT 15
")->fetchAll();
?>

<h4 class="mb-3">Customer কে মেসেজ পাঠান</h4>

<?php if ($success): ?><div class="alert alert-success"><?= h($success) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>

<div class="row g-3">
  <div class="col-md-6">
    <form method="POST" class="card p-4">
      <div class="mb-3">
        <label class="form-label">কাকে পাঠাবেন?</label>
        <div class="d-flex gap-3">
          <div class="form-check">
            <input class="form-check-input" type="radio" name="target" id="targetSingle" value="single" checked onclick="toggleTarget()">
            <label class="form-check-label" for="targetSingle">একজন Customer</label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="target" id="targetAll" value="all" onclick="toggleTarget()">
            <label class="form-check-label" for="targetAll">সব Customer কে (Broadcast)</label>
          </div>
        </div>
      </div>

      <div class="mb-3" id="customerSelectWrap">
        <label class="form-label">Customer বেছে নিন</label>
        <select name="customer_id" class="form-select">
          <option value="">-- Select Customer --</option>
          <?php foreach ($customers as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $preselect==$c['id']?'selected':'' ?>><?= h($c['name']) ?> (<?= h($c['phone']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Channel</label>
        <select name="channel" class="form-select">
          <option value="sms">SMS</option>
          <option value="email">Email</option>
          <option value="both">SMS + Email</option>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">Message</label>
        <textarea name="message" class="form-control" rows="4" placeholder="যেমন: ঈদ উপলক্ষে ৩০% ছাড়! আজই শপে আসুন।" required></textarea>
      </div>

      <button type="submit" class="btn btn-dark"><i class="bi bi-send"></i> Send Message</button>
    </form>
    <p class="text-muted small mt-2">
      <i class="bi bi-info-circle"></i> Real SMS পাঠাতে <code>includes/messaging.php</code> ফাইলে আপনার SMS Gateway API যুক্ত করুন।
    </p>
  </div>

  <div class="col-md-6">
    <div class="card p-3">
      <h6>সাম্প্রতিক পাঠানো মেসেজ</h6>
      <div style="max-height:60vh; overflow-y:auto;">
        <?php foreach ($history as $h): ?>
          <div class="border-bottom py-2">
            <div class="d-flex justify-content-between">
              <strong><?= $h['customer_id'] ? h($h['customer_name']) : 'সবার কাছে (Broadcast)' ?></strong>
              <small class="text-muted"><?= date('d M, h:i A', strtotime($h['created_at'])) ?></small>
            </div>
            <p class="mb-1 small"><?= h($h['message']) ?></p>
            <small class="text-muted">Channel: <?= h($h['channel']) ?> | Recipients: <?= $h['recipient_count'] ?> | By: <?= h($h['sender_name']) ?></small>
          </div>
        <?php endforeach; ?>
        <?php if (empty($history)): ?><p class="text-muted">কোনো মেসেজ পাঠানো হয়নি।</p><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
function toggleTarget() {
  const isAll = document.getElementById('targetAll').checked;
  document.getElementById('customerSelectWrap').style.display = isAll ? 'none' : 'block';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
