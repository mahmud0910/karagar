<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
require_login();
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($page_title) ? h($page_title) . ' - ' : '' ?><?= SITE_NAME ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="/assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark navbar-expand-lg" style="background:#1f2937;">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="/index.php"><i class="bi bi-bag-heart"></i> <?= SITE_NAME ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navMenu">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="/index.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="/pos/index.php"><i class="bi bi-cart4"></i> POS / Billing</a></li>
        <li class="nav-item"><a class="nav-link" href="/products/list.php"><i class="bi bi-box-seam"></i> Products</a></li>
        <li class="nav-item"><a class="nav-link" href="/customers/list.php"><i class="bi bi-people"></i> Customers</a></li>
        <li class="nav-item"><a class="nav-link" href="/sales/history.php"><i class="bi bi-receipt"></i> Sales History</a></li>
        <li class="nav-item"><a class="nav-link" href="/messages/send.php"><i class="bi bi-chat-dots"></i> Messages</a></li>
        <?php if (is_admin()): ?>
        <li class="nav-item"><a class="nav-link" href="/users/list.php"><i class="bi bi-person-badge"></i> Staff</a></li>
        <?php endif; ?>
      </ul>
      <ul class="navbar-nav">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-person-circle"></i> <?= h(current_user_name()) ?> (<?= h(current_user_role()) ?>)
          </a>
          <ul class="dropdown-menu dropdown-menu-end">
            <li><a class="dropdown-item text-danger" href="/logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container-fluid py-4 px-4">
