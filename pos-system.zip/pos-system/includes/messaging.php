<?php
/**
 * =====================================================================
 * SMS / EMAIL SENDING
 * =====================================================================
 * এই function টি আসল SMS পাঠায় না — শুধু ডাটাবেজে log রাখে, যাতে
 * আপনি Sales/Customer panel থেকে দেখতে পারেন কি মেসেজ পাঠানো হয়েছে।
 *
 * আসল SMS পাঠাতে চাইলে (Bangladesh এ জনপ্রিয় গেটওয়ে):
 *   - Alpha SMS       (https://sms.net.bd)
 *   - Bulk SMS BD      (https://bulksmsbd.net)
 *   - Twilio (International)
 *
 * সাধারণত তাদের একটা API URL + API Key দেওয়া থাকে, যেমন:
 *
 *   function send_sms_via_gateway($phone, $message) {
 *       $apiKey = 'YOUR_API_KEY';
 *       $url = "https://api.sms-provider.com/send?api_key=$apiKey&to=$phone&msg=" . urlencode($message);
 *       file_get_contents($url); // অথবা curl ব্যবহার করুন
 *   }
 *
 * সেই function টা এখানে বসিয়ে দিলেই real SMS পাঠানো শুরু হয়ে যাবে।
 * Email পাঠাতে PHPMailer ব্যবহার করা যায় (composer require phpmailer/phpmailer)।
 * =====================================================================
 */

function send_sms_via_gateway($phone, $message) {
    // TODO: এখানে আপনার SMS Gateway এর real API call বসান
    // এখন এটা শুধু log করে রাখে (demo mode)
    return true;
}

function send_email_via_gateway($email, $subject, $message) {
    // TODO: real mail() অথবা PHPMailer/SMTP বসান
    // return mail($email, $subject, $message);
    return true;
}
