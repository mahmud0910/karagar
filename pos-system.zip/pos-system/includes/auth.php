<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Any logged-in user (admin or cashier) can access
 */
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * Only admin can access
 */
function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: /index.php?error=access_denied');
        exit;
    }
}

function current_user_id() {
    return $_SESSION['user_id'] ?? null;
}

function current_user_name() {
    return $_SESSION['user_name'] ?? '';
}

function current_user_role() {
    return $_SESSION['role'] ?? '';
}

function is_admin() {
    return current_user_role() === 'admin';
}
