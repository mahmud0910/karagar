<?php
/**
 * Generate a unique invoice number like INV-20260912-0001
 */
function generate_invoice_no($pdo) {
    $prefix = 'INV-' . date('Ymd') . '-';
    $stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM sales WHERE invoice_no LIKE ?");
    $stmt->execute([$prefix . '%']);
    $cnt = $stmt->fetch()['cnt'] + 1;
    return $prefix . str_pad($cnt, 4, '0', STR_PAD_LEFT);
}

/**
 * Format money with currency symbol
 */
function money($amount) {
    return CURRENCY . ' ' . number_format((float)$amount, 2);
}

/**
 * Safe output escaping
 */
function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Simple flash message via query string redirect
 */
function redirect_with_message($url, $type, $msg) {
    header("Location: $url?$type=" . urlencode($msg));
    exit;
}
