</div>
<footer class="text-center text-muted py-3">
  &copy; <?= date('Y') ?> <?= SITE_NAME ?> — All rights reserved.
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
